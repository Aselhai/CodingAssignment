Q1. b, c, d, e
Q2. (a) Proper
(b) Improper! Because,  a <= b is OK. But, a is not integar.
(c) Proper 
(d) Proper
(e) Improper! Because, a, b, c is integar.(OK!) But, c >= b.