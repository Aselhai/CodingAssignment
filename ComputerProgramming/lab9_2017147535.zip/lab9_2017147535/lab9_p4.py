def drawFlower(myturtle, r):
    for k in range(24):
        myturtle.pencolor('red')
        myturtle.circle(r)
        myturtle.left(15)
