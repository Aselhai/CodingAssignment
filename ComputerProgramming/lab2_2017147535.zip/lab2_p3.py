n1 = int(input('Number 1: '))
n2 = int(input('Number 2: '))

value = n1/n2

print('Result:', format(value, '.2f'))
