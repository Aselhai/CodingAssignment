a = int(input('Enter leftmost digit: '))
b = int(input('Enter the next digit: '))
c = int(input('Enter the next digit: '))
d = int(input('Enter the next digit: '))

v = a*2**3 + b*2**2 + c*2**1 + d*2**0

print('The value is', v)
