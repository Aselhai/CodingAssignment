b = int(input('What base? '))
p = int(input('What power of '+ str(b)+'? '))
n = b**p
print(b, 'to the power of', p, 'is', n)
