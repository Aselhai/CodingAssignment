c = int(input('This program will convert degrees Celsius to degrees Fahrenheit\nEnter degrees Celsius: '))

f = (c * 9/5) + 32

print(c, 'degrees Celsius equals', format(f, '.1f'), 'degrees Fahrenheit')
