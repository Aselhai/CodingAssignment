i = 1

while i <= 10:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 20:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 30:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 40:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 50:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 60:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 70:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 80:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 90:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
print('')

while i <= 100:
    print('{0:3d}'.format(i), end = '')
    i = i + 1
