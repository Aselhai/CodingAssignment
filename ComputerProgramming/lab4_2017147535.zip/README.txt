Q1.
1) 10^18
2) Not for all interger makes loop forever. Because X is interger. X is only enter by intergar(Not infinite)
   But, If some interger like 999999999999999999999999999999 which over computer's limit. I think it can make computer confuse!	
3) ans = 0, Infinite loop

Q2. a, b

Q3.
(a) 24 not in nums
(b) 'Ellen' in names 
(c) 'Morris' in last_name or 'Morrison' in last_name

Q4.
First, num(input by user) is out of while loop, so it is not reflected in result.
Second, If user enter 0, this 0 product together, so printed value is 0.
Last, input type is not int, so computer cognition to str.

Q5. print('John Doe\n123 Main Street\nAnytown, Maryland 21009')

Q6. print("It's raining today.")

Q7.
(a) 2.0
(b) 2
(c) 2.0