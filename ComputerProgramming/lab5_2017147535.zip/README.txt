Q1.
(a) True
(b) True
(c) False
(d) True, False

Q2.
(a) False
(b) True
(c) True
(d) False
(e) True

Q3.
(a) num >= 0 and num < 100
(b) (num < 100 and num >=0) or (num == 200)
(c) 'Thompson' in last_names and 'Wu' not in last_names