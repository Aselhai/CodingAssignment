Q1. 99

Q2.
(a) (var1 * 8) - var2 + (32 / var3)
(b) var1 - (6 ** 4) * (var2 ** 3)

Q3.
(a) ((var1 * var2) * var3) - var4
(b) (var1 * var2) / var3
(c) var1 ** (var2 ** var3)