import random

print('Lotto numbers of the week:', random.randint(1, 45), random.randint(1, 45), random.randint(1, 45), random.randint(1, 45), random.randint(1, 45), random.randint(1, 45))
