Q1.
(a) print(str1[3])
(b) print(str1.index('o'))

Q2.
(a) len(lst)
(b)
n = 0
a = 0

while n < len(lst):
    a = a + len(lst[n])
    n = n + 1
    
print(a)
(c)
n = 0
a = 0

while n < len(lst):
    a = a + sum(lst[n])
    n = n + 1
    
print(a)
(d) lst[3][2] = 12

Q3.
(a) 10, 50
(b) 1, 1
(c) 1, 15
(d) 0, 5